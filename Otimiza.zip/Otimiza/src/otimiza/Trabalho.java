/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package otimiza;

/**
 *
 * @author guimn
 */
public class Trabalho {

    public int turno;

    public Trabalho(int turno) {
        this.turno = turno;
    }
}
