//package otimiza;

import org.gnu.glpk.GLPK;
import org.gnu.glpk.GLPKConstants;
import org.gnu.glpk.GlpkException;
import org.gnu.glpk.SWIGTYPE_p_double;
import org.gnu.glpk.SWIGTYPE_p_int;
import org.gnu.glpk.glp_prob;
import org.gnu.glpk.glp_smcp;
import org.gnu.glpk.SWIGTYPE_p_int;

public class Glpk {

    glp_prob lp;
    glp_smcp parm;
    double M, T, N;
    int quantEnfer = 0;
    SWIGTYPE_p_int ia[] = new SWIGTYPE_p_int[30];
    SWIGTYPE_p_int ja[] = new SWIGTYPE_p_int[30];
    SWIGTYPE_p_double ar[] = new SWIGTYPE_p_double[30];
    double z, x1, x2, x3;

    public void Resolver() {
        try {
            //Criar problema
            lp = GLPK.glp_create_prob();
            GLPK.glp_set_prob_name(lp, "Enfer");
            GLPK.glp_set_obj_dir(lp, GLPK.GLP_MIN);

            GLPK.glp_add_rows(lp, 3);
            GLPK.glp_set_row_name(lp, 1, "M");
            GLPK.glp_set_row_bnds(lp, 1, GLPK.GLP_LO, 0.0, M);
            GLPK.glp_set_row_name(lp, 2, "T");
            GLPK.glp_set_row_bnds(lp, 2, GLPK.GLP_LO, 0.0, T);
            GLPK.glp_set_row_name(lp, 3, "N");
            GLPK.glp_set_row_bnds(lp, 3, GLPK.GLP_LO, 0.0, N);

            GLPK.glp_add_cols(lp, 3);
            GLPK.glp_set_col_name(lp, 1, "x1");
            GLPK.glp_set_col_bnds(lp, 1, GLPK.GLP_UP, 0.0, 0.0);
            GLPK.glp_set_obj_coef(lp, 1, 1.0);
            GLPK.glp_set_col_name(lp, 2, "x2");
            GLPK.glp_set_col_bnds(lp, 2, GLPK.GLP_UP, 0.0, 0.0);
            GLPK.glp_set_obj_coef(lp, 2, 1.0);
            GLPK.glp_set_col_name(lp, 3, "x3");
            GLPK.glp_set_col_bnds(lp, 3, GLPK.GLP_UP, 0.0, 0.0);
            GLPK.glp_set_obj_coef(lp, 3, 1.0);

			for(int i = 0; i < quantEnfer-3; i=i+3){
				ia[i] = (SWIGTYPE_p_int) i;
				ia[i+1] = (SWIGTYPE_p_int) i;
				ia[i+2] = (SWIGTYPE_p_int) i;
			}
			for(int i = 0; i < quantEnfer-3; i=i+3){
				ja[i] = 0;
				ja[i+1] = 1;
				ja[i+2] = 2;
			}


			for(int i = 0; i < quantEnfer; i++){
				ar[i] = 0.0;
            }
            
            GLPK.glp_load_matrix(lp, quantEnfer, ia, ja, ar);
            GLPK.glp_simplex(lp, null);
            z = GLPK.glp_get_obj_val(lp);
            x1 = GLPK.glp_get_col_prim(lp, 1);
            x2 = GLPK.glp_get_col_prim(lp, 2);
            x3 = GLPK.glp_get_col_prim(lp, 3);

            System.out.println(z +" " +x1 +" " +x2 +" " +x3);
        }catch(Exception E){
            System.out.println("");
        }
        
    }

    public static void main(String[] args) {

    }
}
