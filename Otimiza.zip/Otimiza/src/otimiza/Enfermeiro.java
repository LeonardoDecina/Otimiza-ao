/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package otimiza;

/**
 *
 * @author guimn
 */
public class Enfermeiro {

    public String nome;
    public String cofen;
    //votor com a resposta final do quadro de horaro do enfermeiro
    public int diasTrabalho[];
    public int preferencias[];
    public int pesosSetados[];

    public Enfermeiro(String nome, String cofen, int[] preferencias, int[] pesosSetados) {
        this.nome = nome;
        this.cofen = cofen;
        this.preferencias = preferencias;
        this.pesosSetados = pesosSetados;
    }
}
