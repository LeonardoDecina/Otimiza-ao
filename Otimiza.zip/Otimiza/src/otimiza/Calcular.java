/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package otimiza;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author guimn
 */
public class Calcular {

    Scanner read = new Scanner(System.in);
    //vetores que contem a quantidade de enfermeiros minimo que um turno deve ter
    int manha[] = new int[28];
    int tarde[] = new int[28];
    int noite[] = new int[28];
    //variaveis que indicam a quandtidade atual de cada enferemeiro no turno especifico
    int quantManha = 0;
    int quantTarde = 0;
    int quantNoite = 0;
    //peso para cada turno
    final int pesoManha = 1;
    final int pesoTarde = 2;
    final int pesoNoite = 3;
    int quantEnferemeiros;
    private int z = 0;
    //vetor com a quantidade de enfermeiros contratados pelo hospital
    Enfermeiro enfermeiros[];

    //ler os enfermeiros de uma entrada padrao
    public String lerEnfermeiros(String arquivo) {
        String aux = "";
        
        try {

            FileReader arq = new FileReader(arquivo);
            BufferedReader lerArq = new BufferedReader(arq);
            
            aux += quantEnferemeiros = Integer.parseInt(lerArq.readLine());
            aux += "\n";
            enfermeiros = new Enfermeiro[quantEnferemeiros];

            for (int k = 0; k < quantEnferemeiros; k++) {

                String nome = lerArq.readLine();
                aux += nome +"\n";
                String cofen = lerArq.readLine();
                aux += cofen +"\n";
                int auxDias[] = new int[28];
                int auxTurnos[] = new int[28];

                for (int w = 0; w < 28; w++) {

                    auxDias[w] = Integer.parseInt(lerArq.readLine());
                    aux += auxDias[w] +"\n";
                }

                for (int w = 0; w < 28; w++) {

                    auxTurnos[w] = Integer.parseInt(lerArq.readLine());
                    aux += auxTurnos[w] +"\n";
                }
                enfermeiros[k] = new Enfermeiro(nome, cofen, auxDias, auxTurnos);
            }
            arq.close();
        } catch (IOException e) {
            System.err.printf("Erro na abertura do arquivo: %s.\n",
                    e.getMessage());
        }
        
        return aux;
    }

    //primeira restricao que garante a quantidade minima e maxima de trabalho de cada enfermeiro
    public boolean restricao01() {
        int auxSoma = 0;

        for (int i = 0; i < quantEnferemeiros; i++) {
            for (int dias = 0; dias < 28; dias++) {
                if (enfermeiros[i].preferencias[dias] != 0) {
                    auxSoma++;
                }
            }
        }

        if (auxSoma >= 16 && auxSoma <= 24) {
            return true;
        }

        return false;
    }

    //segunda restricao que garante a quantidade minima de enfermeiros em cada turno
    public boolean restricao02() {
        int auxSomaTM = 0;
        int auxSomaTT = 0;
        int auxSomaTN = 0;

        int auxSomaFolgaTM = 0;
        int auxSomaFolgaTT = 0;
        int auxSomaFolgaTN = 0;

        //faz os calculos de enfermeiros trabalhando e dos que estão de folga em cada turno
        for (int i = 0; i < quantEnferemeiros; i++) {
            for (int dias = 0; dias < 28; dias++) {
                if (enfermeiros[i].pesosSetados[dias] == 1) {
                    auxSomaTM++;
                }

                if (enfermeiros[i].pesosSetados[dias] == 2) {
                    auxSomaTT++;
                }

                if (enfermeiros[i].pesosSetados[dias] == 3) {
                    auxSomaTN++;
                }
            }
        }

        for (int i = 0; i < 28; i++) {
            quantManha += manha[i];
            quantTarde += tarde[i];
            quantNoite += noite[i];
        }

        //verifica se em cada turno há uma quantidade minima de enferemeiros disponiveis
        if ((auxSomaTM - auxSomaFolgaTM >= quantManha)
                && (auxSomaTT - auxSomaFolgaTT >= quantTarde)
                && (auxSomaTN - auxSomaFolgaTN >= quantNoite)) {
            return true;
        }

        return false;
    }

    //funcao objetiva na qual queremos minimizar a quantidade de enfermeiros no hospital
    public int funcaoObjetiva() {
        for (int i = 0; i < quantEnferemeiros; i++) {
            for (int dias = 0; dias < 28; dias++) {
                z = enfermeiros[i].preferencias[dias] * enfermeiros[i].pesosSetados[dias];
            }
        }
        return z;
    }

    public static void main(String[] args) {
    }
}
